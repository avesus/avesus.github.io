"""Execute the actual ARM ELF and count instructions, not simulated CPU cycles.

Unicorn does not model Cortex-M4 bus/FPU stalls or the instrument scheduler.
These counts compare implementations; they cannot certify the audio deadline.
"""
import collections,json,pathlib,struct,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'external/arm-audit-python'))
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_THUMB,UC_MODE_MCLASS,UC_HOOK_BLOCK
from unicorn.arm_const import *
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM,CS_MODE_THUMB,CS_MODE_MCLASS

class Image:
    def __init__(self,path):
        self.u=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS)
        self.u.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_M4)
        self.u.mem_map(0x20000000,0x40000)
        self.u.mem_map(0x08000000,0x100000)
        self.u.mem_map(0xe0000000,0x100000)
        self.u.reg_write(UC_ARM_REG_C1_C0_2,0xf<<20)
        self.u.reg_write(UC_ARM_REG_FPEXC,1<<30)
        self.u.mem_write(0xe000ed88,struct.pack('<I',0xf<<20))
        with open(path,'rb') as f:
            elf=ELFFile(f)
            for segment in elf.iter_segments():
                if segment['p_type']=='PT_LOAD' and segment['p_filesz']:
                    self.u.mem_write(segment['p_vaddr'],segment.data())
            symtab=elf.get_section_by_name('.symtab')
            self.syms={s.name:s['st_value'] for s in symtab.iter_symbols()}
        self.count=0;self.blocks={};self.hist=collections.Counter()
        self.cs=Cs(CS_ARCH_ARM,CS_MODE_THUMB|CS_MODE_MCLASS)
        self.u.hook_add(UC_HOOK_BLOCK,self.block)
        self.call('_entry',0x200,0x10100)
    def block(self,u,address,size,_):
        if address not in self.blocks:
            ins=list(self.cs.disasm(bytes(u.mem_read(address,size)),address))
            self.blocks[address]=(len(ins),collections.Counter(i.mnemonic for i in ins))
        n,h=self.blocks[address];self.count+=n;self.hist.update(h)
    def call(self,name,*args):
        self.u.reg_write(UC_ARM_REG_SP,0x2003e000)
        self.u.reg_write(UC_ARM_REG_LR,0x2003f001)
        for reg,value in zip((UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3),args):self.u.reg_write(reg,value)
        self.count=0;self.hist.clear()
        self.u.emu_start(self.syms[name]|1,0x2003f000,count=10000000)
        assert self.u.reg_read(UC_ARM_REG_PC)==0x2003f000, 'ARM call did not return'
        return self.count
    def params(self,note):
        self.u.mem_write(0x20030000,struct.pack('<iHHH3H',0,note*256,0,0,0,0,0))
    def cycle(self):
        n=self.call('_hook_cycle',0x20030000,0x20030100,64)
        x=struct.unpack('<64i',self.u.mem_read(0x20030100,256))
        return n,max(abs(v) for v in x)/2147483648

def audit(path):
    image=Image(path);results={}
    for name,note,width,density in [('A4_medium',69,460,100),('A4_wide',69,1023,100),('C7_wide',96,1023,100),('A4_wide_density_0',69,1023,0)]:
        image.call('_hook_init',0x200,0x10100)
        image.call('_hook_param',0,density)
        image.call('_hook_param',1,0)
        image.call('_hook_param',6,width)
        image.params(note);on_count=image.call('_hook_on',0x20030000)
        counts=[];peak=0
        for _ in range(128):
            n,p=image.cycle();counts.append(n);peak=max(peak,p)
        # A width change exercises the expensive control path in both builds.
        image.call('_hook_param',6,1023-width)
        modulation=[image.cycle()[0] for _ in range(64)]
        results[name]={'note_on_instructions':on_count,
          'steady_instructions_per_sample':sum(counts)/(len(counts)*64),
          'max_steady_64_frame_instructions':max(counts),
          'max_width_change_64_frame_instructions':max(modulation),'output_peak':peak}
    results['linked_software_double_helpers']=[n for n in image.syms if n.startswith('__aeabi_d') or n in ('powf','exp2f','sinf','cosf')]
    return results

def main():
    started=time.time()
    report={'method':'Actual ARM M4 ELF emulation and executed instruction counts; NOT cycle-accurate or a hardware deadline measurement.'}
    for version,path in [('v0.2',ROOT/'archive/v0.2-original-timbre/build/square-cloud.elf'),('v0.3_preview',ROOT/'build/square-cloud.elf')]:
        report[version]=audit(path)
        print(version,json.dumps(report[version],indent=2),flush=True)
    report['wall_seconds']=time.time()-started
    (ROOT/'renders/arm-audit.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
