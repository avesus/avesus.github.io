"""Bundle the v0.5 unit, source, verification and auditions; preserve v0.4."""
from pathlib import Path
import hashlib,json,shutil,zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
files=[p for p in HERE.glob('*') if p.is_file()]
files+=list((HERE/'src').glob('*'))
files+=[p for p in (HERE/'dist').glob('*') if p.suffix!='.zip']
files+=[p for p in (HERE/'renders').glob('*') if p.suffix in ('.wav','.json','.png')]
files+=[HERE/'build'/n for n in ('sqbell.elf','sqbell.map','build-manifest.json')]
files+=[ROOT/'src/host.cpp',ROOT/'scripts/arm_audit.py',ROOT/'THIRD_PARTY_LICENSES.txt']
files+=[ROOT/'prototypes/sqbell16/dist'/n for n in ('sqbell16.js','sqbell16.wasm')]
out=HERE/'dist/sqbell-v0.5.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):z.write(p,str(Path('minilog_xd')/p.relative_to(ROOT)))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for p in files:
        assert z.read(str(Path('minilog_xd')/p.relative_to(ROOT)).replace('\\','/'))==p.read_bytes()
unit=HERE/'dist/sqbell-v0.5.mnlgxdunit'
shutil.copy2(unit,ROOT/'dist'/unit.name)
assert hashlib.sha256((ROOT/'dist'/unit.name).read_bytes()).digest()==hashlib.sha256(unit.read_bytes()).digest()
old=ROOT/'prototypes/sqbell16/dist/sqbell16-v0.4.mnlgxdunit'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='6dfa281190c6c43292305a5cda8ee891e3697aa3cae06dd8a08e56a07abee7c3'
assert hashlib.sha256((ROOT/'dist/square-cloud-v0.2.mnlgxdunit').read_bytes()).hexdigest()=='682291bdfdbd299eb13f45ae42738d98c1f2e13dd671fc2f484c56427bf1dd0d'
print(json.dumps({'package':str(out),'bytes':out.stat().st_size,'files':len(files),
                  'unit':str(ROOT/'dist'/unit.name),'unit_sha256':hashlib.sha256(unit.read_bytes()).hexdigest(),
                  'working_v04_and_original_v02_unchanged':True},indent=2))
