const fs=require('fs'),path=require('path'),assert=require('assert');
const create=require('./dist/sqbell.js'),createOld=require('../sqbell16/dist/sqbell16.js');
const SR=48000,dir=path.join(__dirname,'renders');fs.mkdirSync(dir,{recursive:true});
function wav(name,x){
 const b=Buffer.alloc(44+x.length*3);b.write('RIFF');b.writeUInt32LE(b.length-8,4);b.write('WAVEfmt ',8);
 b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(SR,24);
 b.writeUInt32LE(SR*3,28);b.writeUInt16LE(3,32);b.writeUInt16LE(24,34);b.write('data',36);b.writeUInt32LE(x.length*3,40);
 for(let i=0;i<x.length;i++){assert(Number.isFinite(x[i])&&Math.abs(x[i])<1);b.writeIntLE(Math.round(x[i]*8388607),44+i*3,3);}
 fs.writeFileSync(path.join(dir,name),b);
}
function peakNormalize(x){let peak=0;for(const y of x)peak=Math.max(peak,Math.abs(y));const gain=10**(-3/20)/peak;for(let j=0;j<x.length;j++)x[j]*=gain;return gain;}
function rmsMatch(x){let e=0;for(const y of x)e+=y*y;const gain=.12/Math.sqrt(e/x.length);for(let j=0;j<x.length;j++)x[j]*=gain;return gain;}
function render(m,n,block=64){const x=new Float64Array(n);for(let o=0;o<n;o+=block){const count=Math.min(block,n-o),p=m._host_render(count)>>>2;for(let j=0;j<count;j++)x[o+j]=m.HEAP32[p+j]/2147483648;}return x;}
function setup(m,n=32,note=69,shape=562){m._host_init(1);m._host_param(0,n-1);m._host_param(6,shape);m._host_note(note*256);}
function plucks(m,n,shape=562){
 const out=new Float64Array(SR*3);
 for(let strike=0;strike<2;strike++){
  setup(m,n,69,shape);const x=render(m,Math.round(SR*1.4));
  for(let j=0;j<x.length;j++){const t=j/SR,env=(1-Math.exp(-t/.002))*Math.exp(-t/.45)*Math.min(1,(1.4-t)/.025);out[strike*SR*1.5+j]=x[j]*env;}
 }return out;
}
(async()=>{
 const m=await create(),old=await createOld();
 m._host_init(1);
 const report={state_bytes:m._cloud_state_bytes(),checks:{},width_checks:[],analysis:[],audio:[]};
 assert.equal(m._cloud_sources(),32);report.checks.init_density=32;
 let peak=0;
 // All displayed Density values must reach the requested count, even when edited during a held note.
 setup(m,16);
 for(let n=16;n<=96;n++){m._host_param(0,n-1);const x=render(m,256);assert.equal(m._cloud_sources(),n);for(const y of x){assert(Number.isFinite(y));peak=Math.max(peak,Math.abs(y));}}
 for(let n=96;n>=16;n--){m._host_param(0,n-1);render(m,256);assert.equal(m._cloud_sources(),n);}
 report.checks.all_81_density_values_both_directions=true;report.checks.density_edit_peak=peak;
 assert(peak<.8);
 for(const [raw,expected] of [[0,16],[14,16],[95,96],[65535,96]]){setup(m);m._host_param(0,raw);render(m,256);assert.equal(m._cloud_sources(),expected);}
 report.checks.out_of_range_density_clamped=true;
 for(const shape of [0,256,512,768,1023]){
  let sigma;
  for(const n of [16,32,64,96])for(const note of [24,48,69,96,108]){
   setup(m,n,note,shape);if(sigma===undefined)sigma=m._cloud_sigma();assert.equal(m._cloud_sigma(),sigma);
   for(const y of render(m,1024)){assert(Number.isFinite(y));assert(Math.abs(y)<.8);}
  }
  assert(Math.abs(sigma-(2+2398*(shape/1023)**3))<.002);report.width_checks.push({shape,sigma_hz:sigma});
 }
 setup(m,96);const a=render(m,SR,17);setup(m,96);assert.deepStrictEqual(a,render(m,SR,1024));report.checks.block_size_invariant=true;
 setup(m,96);const attack=render(m,SR);m._host_note(69*256);assert.deepStrictEqual(attack,render(m,SR));report.checks.coherent_retrigger=true;
 setup(m,64);const sigma=m._cloud_sigma(),spacing=m._cloud_spacing();m._host_pitch(81*256);render(m,128);
 assert.equal(m._cloud_sigma(),sigma);assert.equal(m._cloud_spacing(),spacing);assert(Math.abs(m._cloud_center()-880)<.001);report.checks.pitch_translation_only=true;
 setup(m,96,69,1023);let holdPeak=0;
 for(let j=0;j<60*SR/1024;j++)for(const y of render(m,1024)){assert(Number.isFinite(y));holdPeak=Math.max(holdPeak,Math.abs(y));}
 assert(holdPeak<.8);report.checks.minute_hold_peak=holdPeak;
 setup(m);const before=m._cloud_sigma();m._host_lfo(1073741824);render(m,SR);assert(m._cloud_sigma()>before);report.checks.shape_lfo=true;
 for(let j=0;j<1500;j++){m._host_param(6,j%1024);if(j%7===0)m._host_param(0,15+j%81);m._host_pitch((24+j%104)*256);for(const y of render(m,64)){assert(Number.isFinite(y));assert(Math.abs(y)<.8);}}
 report.checks.combined_density_width_pitch_modulation=true;
 const parity=[];
 for(const [n,note,shape] of [[16,69,460],[32,69,1023],[64,96,1023],[95,69,512],[96,69,1023]]){
  setup(m,n,note,shape);const x=render(m,1024);parity.push({density:n,note,shape,samples:Array.from(x,y=>Math.round(y*2147483648))});
 }
 fs.writeFileSync(path.join(__dirname,'build/wasm-reference.json'),JSON.stringify(parity));
 // Raw compiled output for independent Fourier analysis at a non-overlapping center/width.
 for(const spec of [{id:'old16',m:old,n:16},...([16,32,64,96].map(n=>({id:`new${n}`,m,n})))]){
  setup(spec.m,spec.n,81,352);const raw=render(spec.m,SR*4);
  fs.writeFileSync(path.join(dir,`${spec.id}.f64`),Buffer.from(raw.buffer));
  report.analysis.push({id:spec.id,density:spec.n,center:880,shape:352,sigma:spec.m._cloud_sigma(),spacing:spec.m._cloud_spacing(),step:spec.id==='old16'?null:spec.m._cloud_step()>>>0,normalization:spec.m._cloud_normalization()});
 }
 const densityAudio=new Float64Array(SR*12),densitySections=[];
 for(const [index,n] of [16,32,64,96].entries()){
  const part=plucks(m,n);const gain=rmsMatch(part);densityAudio.set(part,index*SR*3);
  densitySections.push({start:index*3,end:index*3+3,density:n,sigma_hz:m._cloud_sigma(),rms_gain:gain});
 }
 const commonGain=peakNormalize(densityAudio);wav('sqbell-density-16-32-64-96.wav',densityAudio);
 report.audio.push({file:'sqbell-density-16-32-64-96.wav',sections:densitySections,common_gain:commonGain,note:'A4; same Gaussian sigma about 400 Hz; equal RMS per section, then one common peak gain; external pluck envelopes, no effects.'});
 const comparison=new Float64Array(SR*7);
 const oldPart=plucks(old,16),newPart=plucks(m,16);const oldGain=rmsMatch(oldPart),newGain=rmsMatch(newPart);
 comparison.set(oldPart);comparison.set(newPart,SR*4);peakNormalize(comparison);wav('sqbell16-old-then-sqbell-new.wav',comparison);
 report.audio.push({file:'sqbell16-old-then-sqbell-new.wav',sections:[{start:0,end:3,version:'SqBell16 v0.4',density:16,rms_gain:oldGain},{start:4,end:7,version:'SqBell v0.5',density:16,rms_gain:newGain}],note:'Same pitch, width, component count, and external envelope; equal RMS. One-second silence between sections.'});
 const payload=fs.readFileSync(path.join(__dirname,'build/payload.bin'));
 assert.equal(payload.subarray(0,4).toString(),'UOSC');assert.equal(payload.readUInt32LE(4),0x10100);assert.equal(payload[8],2);
 for(const offset of [16,20,24,28,32,40]){const p=payload.readUInt32LE(offset);assert(p&1);assert(p>=0x20000000&&p<0x20008000);}
 const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'manifest.json')));
 assert.deepStrictEqual(manifest.header.params,[['Density',15,95,'']]);
 report.sdk={api:'1.1.0',platform:2,valid_thumb_hooks:true,payload_bytes:payload.length,density_display:'16..96 (SDK typeless +1 display offset)'};
 fs.writeFileSync(path.join(dir,'render-report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
