"""Independent ideal-sum comparison and plots from compiled WASM output."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

HERE=Path(__file__).resolve().parent
OUT=HERE/'renders'
FS=48000
render=json.loads((OUT/'render-report.json').read_text())
report={'method':'Time-domain error against an independently computed ideal finite Gaussian sum, at A5 and sigma approximately 100 Hz. Includes square harmonics, aliases and numerical error. No hardware recording.', 'cases':[]}
fig,axes=plt.subplots(3,1,figsize=(11,8),layout='constrained',sharex=True)
plot_cases={'old16':0,'new16':1,'new96':2}
for spec in render['analysis']:
    x=np.fromfile(OUT/(spec['id']+'.f64'),dtype='<f8')
    n=spec['density'];half=n//2;offsets=np.arange(-half,half)
    normalized=offsets*(4/half)
    weights=np.exp(-.5*normalized**2)
    if spec['id']=='old16':
        steps=(abs(offsets).astype(np.float32)*np.float32(spec['spacing'])*np.float32(4294967296/FS)).astype(np.uint32)
        amps=np.rint(16384*weights)*1.054786175*spec['normalization']
    else:
        steps=abs(offsets)*spec['step']
        amps=16384*weights*np.sinc(1/16)*spec['normalization']
    frequencies=spec['center']+np.sign(offsets)*steps.astype(np.float64)*(FS/4294967296)
    t=np.arange(len(x))/FS
    target=np.zeros_like(x)
    for hz,amplitude in zip(frequencies,amps):target+=amplitude*np.cos(2*np.pi*hz*t)
    error=x-target
    residual=float(10*np.log10(np.mean(error**2)/np.mean(target**2)))
    case={'id':spec['id'],'density':n,'sigma_hz':spec['sigma'],
          'spacing_hz':spec['spacing'],'ideal_sum_error_power_db':residual,
          'intended_components_within_6_db':int(np.count_nonzero(weights>=10**(-6/20)))}
    report['cases'].append(case)
    if spec['id'] in plot_cases:
        ax=axes[plot_cases[spec['id']]]
        win=np.hanning(len(x));fft=2*abs(np.fft.rfft(x*win))/sum(win)
        f=np.fft.rfftfreq(len(x),1/FS)
        center_amp=amps[offsets==0][0]
        ax.plot(f,20*np.log10(np.maximum(fft/center_amp,1e-7)),color='#008b90',lw=.85)
        ideal_f=np.linspace(480,1280,1000)
        ax.plot(ideal_f,-(10/np.log(10))*((ideal_f-spec['center'])/spec['sigma'])**2,'--',color='#cc7226',lw=1,label='Intended Gaussian amplitude envelope')
        ax.set(title=f"{spec['id']}: {n} components; {case['intended_components_within_6_db']} within 6 dB of the peak",ylabel='Relative amplitude (dB)',ylim=(-65,3),xlim=(480,1280))
        ax.grid(alpha=.2)
axes[0].legend(loc='lower center');axes[-1].set_xlabel('Frequency (Hz)')
fig.suptitle('Density changes spectral spacing while Gaussian width stays fixed')
fig.savefig(OUT/'density-spectrum.png',dpi=160);plt.close(fig)
old,new=report['cases'][0],report['cases'][1]
report['same_density_error_reduction_db']=old['ideal_sum_error_power_db']-new['ideal_sum_error_power_db']
assert report['same_density_error_reduction_db']>5.0,report
assert all(c['ideal_sum_error_power_db']<-18 for c in report['cases'][1:]),report
# Check the actual mixer's harmonic suppression by integrating its piecewise levels.
levels=np.sin((np.arange(16)+.5)*2*np.pi/16)
phase=(np.arange(16)+.5)*2*np.pi/16
coeff={}
for h in [1,3,5,7,9,11,13,15,17]:
    c=np.sum(levels*np.exp(-1j*h*phase))/8*np.sinc(h/16)
    coeff[str(h)]=float(abs(c))
assert max(coeff[str(h)] for h in [3,5,7,9,11,13])<1e-14
report['ideal_sign_mixer_harmonic_amplitudes']=coeff
(OUT/'spectrum-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
