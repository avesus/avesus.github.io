#include "userosc.h"
#include "bell.hpp"
static bell::Oscillator oscillator;
static unsigned control=0;
static uint16_t lastPitch=0xffff;
static float lastHz=440.f;
static float noteFrequency(uint16_t pitch) {
  static const float octave[12]={8.175798916f,8.661957218f,9.177023997f,9.722718241f,
    10.300861154f,10.913382232f,11.562325710f,12.249857374f,12.978271799f,
    13.75f,14.567617547f,15.433853164f};
  if(pitch==lastPitch)return lastHz;
  unsigned note=pitch>>8;if(note>127)note=127;
  const float f0=octave[note%12]*float(1u<<(note/12));
  lastHz=f0*(1.f+float(pitch&255)*(.0594630943593f/255.f));lastPitch=pitch;
  return lastHz;
}
void OSC_INIT(uint32_t platform,uint32_t api) {
  (void)platform;(void)api;oscillator.init();control=0;lastPitch=0xffff;
}
void OSC_CYCLE(const user_osc_param_t * const params,int32_t *yn,uint32_t frames) {
  for(unsigned j=0;j<frames;++j) {
    if(!control) {
      const float knob=oscillator.width;
      oscillator.width=bell::clamp(knob+float(params->shape_lfo)*(.5f/2147483648.f),0.f,1.f);
      oscillator.configure(noteFrequency(params->pitch));oscillator.width=knob;
    }
    control=(control+1)&63u;
    yn[j]=int32_t(oscillator.tick()*2147483647.f);
  }
}
void OSC_NOTEON(const user_osc_param_t * const params) {
  control=0;oscillator.noteOn(noteFrequency(params->pitch));
}
void OSC_NOTEOFF(const user_osc_param_t * const params){(void)params;}
void OSC_MUTE(const user_osc_param_t * const params){(void)params;oscillator.muted=true;}
void OSC_PARAM(uint16_t id,uint16_t value){oscillator.parameter(id,value);}
#ifdef CLOUD_HOST
extern "C" {
void cloud_seed(unsigned seed){(void)seed;oscillator.init();}
float cloud_sigma(){return oscillator.sigma;}
float cloud_center(){return oscillator.center;}
float cloud_spacing(){return oscillator.spacing;}
float cloud_normalization(){return oscillator.normalization;}
unsigned cloud_state_bytes(){return sizeof(oscillator);}
unsigned cloud_sources(){return oscillator.count;}
unsigned cloud_step(){return oscillator.step;}

}
#endif
