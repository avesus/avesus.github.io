// Gaussian-weighted square DDS with phase-coherent quadrature translation.
#pragma once
#include <stdint.h>
#include <string.h>
#include "weights.hpp"
namespace bell {
inline float clamp(float x,float lo,float hi){return x<lo?lo:x>hi?hi:x;}
struct Oscillator {
  const Coeff *weights;
  uint32_t phase,step,clock;
  unsigned count,half,pending;
  float width,widthCurrent,sigma,spacing,center,normalization;
  float carrierI,carrierQ,rotateCos,rotateSin,level;
  bool muted;

  // Algebraically reduced 16-phase weighted-square mixer. Four coefficients
  // set a base level plus three square-transition increments. Phase bits
  // select the already-combined sign-mixer levels, packed two per word.
  // This folds the weighted square additions into integer bit operations.
  // Compared with v0.4's 8-phase mixer, odd harmonics 3..13 cancel.
  static int square(uint32_t p,const Coeff &w) {
    const unsigned folded=((p^uint32_t(-int32_t((p>>30)&1u)))>>28)&3u;
    // Both build targets are little-endian. memcpy avoids aliasing violations
    // and compiles to a single halfword load of the combined mixer coefficient.
    uint16_t magnitude;
    __builtin_memcpy(&magnitude,reinterpret_cast<const unsigned char*>(&w)+2*folded,2);
    const int v=magnitude;
    return (p&0x80000000u)?-v:v;
  }
  void rotation(float hz) {
    const float a=hz*(6.283185307179586f/48000.f),z=a*a;
    rotateSin=a*(1.f+z*(-1.f/6.f+z*(1.f/120.f+z*(-1.f/5040.f+z*(1.f/362880.f-z/39916800.f)))));
    rotateCos=1.f+z*(-1.f/2.f+z*(1.f/24.f+z*(-1.f/720.f+z*(1.f/40320.f+z*(-1.f/3628800.f+z/479001600.f)))));
  }
  void select(unsigned n) {
    count=n<16?16:n>96?96:n;half=count/2;
    const Bank &bank=kBanks[half-8];weights=kCoefficients+bank.offset;
    normalization=(count&1u)?bank.oddGain:bank.evenGain;
    spacing=4.f*sigma/float(half);
    step=uint32_t(spacing*(4294967296.f/48000.f));
  }
  void configure(float hz,bool immediate=false) {
    hz=clamp(hz,20.f,12000.f);
    if(hz!=center||immediate){center=hz;rotation(hz);}
    if(level==0.f&&pending!=count)select(pending);
    const float distance=width-widthCurrent;
    if(!immediate&&distance<.000001f&&distance>-.000001f)return;
    widthCurrent=immediate?width:widthCurrent+distance*.125f;
    sigma=2.f+2398.f*widthCurrent*widthCurrent*widthCurrent;
    spacing=4.f*sigma/float(half);
    step=uint32_t(spacing*(4294967296.f/48000.f));
  }
  void init() {
    memset(this,0,sizeof(*this));width=widthCurrent=.45f;carrierI=1.f;level=1.f;
    sigma=2.f+2398.f*width*width*width;pending=32;select(pending);configure(440.f,true);
  }
  void noteOn(float hz) {
    phase=clock=0;carrierI=1.f;carrierQ=0.f;level=1.f;muted=false;
    select(pending);configure(hz,true);
  }
  void parameter(unsigned id,unsigned value) {
    if(id==0)pending=value<15?16:value>=95?96:unsigned(value)+1;
    if(id==6)width=clamp(float(value)/1023.f,0.f,1.f);
  }
  float tick() {
    if(muted)return 0.f;
    // Frequencies are integer multiples of spacing; p += phase evaluates
    // the exact phase of each component. Density still adds distinct lines.
    uint32_t p=phase;int pairs=0;
    unsigned j=0;
    for(;j+3<half-1;j+=4) {
      pairs+=square(p+0x40000000u,weights[j]);p+=phase;
      pairs+=square(p+0x40000000u,weights[j+1]);p+=phase;
      pairs+=square(p+0x40000000u,weights[j+2]);p+=phase;
      pairs+=square(p+0x40000000u,weights[j+3]);p+=phase;
    }
    for(;j<half-1;++j,p+=phase)pairs+=square(p+0x40000000u,weights[j]);
    const int outerI=square(p+0x40000000u,kOuter);
    const int i=2*pairs+kCenter+((count&1u)?2*outerI:outerI);
    const int q=(count&1u)?0:-square(p,kOuter);
    // A density edit uses a 64-sample fade out, a bank switch while silent,
    // then a 64-sample fade in. No doubled synthesis load during the edit.
    if(pending!=count)level=level>0.f?level-1.f/64.f:0.f;
    else if(level<1.f)level+=1.f/64.f;
    const float y=(float(i)*carrierI-float(q)*carrierQ)*(normalization*level);
    phase+=step;
    const float nextI=carrierI*rotateCos-carrierQ*rotateSin;
    carrierQ=carrierQ*rotateCos+carrierI*rotateSin;carrierI=nextI;
    if((++clock&255u)==0) {
      const float r=1.5f-.5f*(carrierI*carrierI+carrierQ*carrierQ);
      carrierI*=r;carrierQ*=r;
    }
    return y;
  }
};
} // namespace bell
