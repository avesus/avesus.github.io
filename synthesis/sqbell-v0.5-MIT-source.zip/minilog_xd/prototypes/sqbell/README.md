# SqBell v0.5 — adjustable Density and stronger square-mixer harmonic rejection

The instrument name is **SqBell**. This version restores **Density**, displayed
as the actual intended component count **16–96**. It is separate from the
working SqBell16 v0.4 unit; that build and its sources remain unchanged.

## Controls

1. Select the USER oscillator **SqBell** with TYPE on the instrument.
2. Enter PROGRAM EDIT, press button **10 (MULTI ENGINE)**, and select parameter
   1, **Density**. Turn PROGRAM/VALUE to choose the count, for example 32 or 64.
3. **SHAPE** still controls Gaussian amplitude-spectrum width in Hz. Played
   pitch still translates the intended Gaussian center.
4. Save the program with WRITE if the setting should persist.

The menu location is documented on page 36 of the
[Korg owner's manual](https://cdn.korg.com/us/support/download/files/f75090725e8541eddad788a94e8c3cba.pdf).
The SDK's typeless parameter display adds one to its stored value: manifest
limits 15–95 are displayed as 16–96; the oscillator converts with `value+1`.
Initialization selects 32, but stored program parameter values can override
that. Explicitly check the Density value on the synth.

SHAPE uses the same mapping as SqBell16: `sigma = 2 + 2398 * SHAPE^3` Hz,
with SHAPE normalized to 0–1. Neither pitch nor Density changes sigma.

| Density | Distinct intended components | Components within 6 dB of the peak | Spacing at sigma 100 Hz |
|---:|---:|---:|---:|
| 16 | 16 | 5 | 50 Hz |
| 32 | 32 | 9 | 25 Hz |
| 64 | 64 | 19 | 12.5 Hz |
| 96 | 96 | 29 | 8.33 Hz |

The small number of prominent lines in SqBell16 came partly from placing 16
components across eight standard deviations of the Gaussian. Many components
were intentionally weak. Higher Density now puts more components inside the
same spectral envelope. Sixteen is a selectable lower limit, not an assumption
about the user's intended synthesis.

## Construction and signal quality

The Gaussian weights remain at the individual inputs. Each quadrature uses
seven weighted, phase-shifted square branches. Their algebraic sum is evaluated
with phase-bit folding and four combined positive mixer levels per component,
stored as two packed coefficient words. No output Gaussian filter is used.
The exact seven-square construction and its reduction are in
`generate_weights.py`; it is not a dense sampled sine-wave oscillator table.

This 16-phase sign mixer cancels odd harmonics 3 through 13 in the ideal
coefficient limit, compared with the old 8-phase mixer's cancellation of 3
and 5. The first remaining families are 15/17 and higher. Integer coefficient
rounding and discrete-time aliases remain. The measured comparison against
an independent ideal Gaussian sum at A5 / sigma about 100 Hz is:

| Build | Density | Error power relative to ideal signal |
|---|---:|---:|
| SqBell16 v0.4 | 16 | -14.22 dB |
| SqBell v0.5 | 16 | -20.32 dB |
| SqBell v0.5 | 32 | -19.54 dB |
| SqBell v0.5 | 64 | -19.32 dB |
| SqBell v0.5 | 96 | -19.36 dB |

That is about 6.1 dB less error power at the same 16-component count. It is a
measured improvement, not an exact-Gaussian or alias-free claim. More Density
means closer lines, not automatically less harmonic distortion.

Phases remain coherent. For N components, M=floor(N/2), spacing is 4*sigma/M.
Even N uses offsets -M through M-1; odd N uses -M through M. Conjugate pairs
share evaluation, and their phases are integer multiples of one shared DDS
phase accumulator. Every counted component has its own frequency and Gaussian
weight; they are not independent randomly phased oscillators. One sample-rate
carrier rotation translates the result to the played note's center.

As in SqBell16, signed frequencies mirror in real output. Broad Gaussians can
overlap their mirrored lobes, shifting the real spectrum's largest peak away
from the intended center. Width is not narrowed based on pitch. This remains
a finite line spectrum, and spacing affects the waveform's periodicity.

Density edits use a short fade down, switch the coefficient bank, and fade
back up, lasting roughly 2.7–4 ms. This avoids an abrupt bank-change click
without running two banks simultaneously. Normalization preserves peak
headroom, so raw RMS level decreases as coherent Density increases.

## Listen and validate

- `renders/sqbell-density-16-32-64-96.wav`: four three-second sections, A4 and
  sigma about 400 Hz throughout, Density 16, 32, 64, then 96. Each section has
  two plucks. Sections have equal RMS followed by one common peak adjustment.
- `renders/sqbell16-old-then-sqbell-new.wav`: 0–3 seconds is SqBell16 v0.4;
  3–4 seconds is silence; 4–7 seconds is SqBell v0.5. Both have 16 components,
  identical pitch, width and external pluck envelope, with matched RMS.
- `renders/density-spectrum.png`: spectrum comparison at fixed width.

WAVs are rendered by compiled WASM through the real XD SDK callbacks, 48 kHz,
mono, 24-bit PCM. Only an external VCA-style envelope is added; there are no
effects. The original v0.4 WAV/code/unit remain preserved.

The actual ARM ELF uses 12,196 bytes text, 16 data and 80 BSS: **12,292 bytes**
total. Measured executed instructions per sample are approximately 239 at
Density 16, 351 at 32, 575 at 64 and 799 at 96. At Density 96 the widest width
and C7 tests have similar cost. Width changes do not produce v0.3's large
reconfiguration bursts. The largest measured density-change block is 51,524
instructions for 64 samples.

These are emulator instruction counts, not CPU cycle timings. High Density
is substantially more expensive; 64 and 96 are not certified to meet the
instrument's polyphonic deadline. Start at 32 when checking the hardware.
SqBell16 v0.4 was confirmed working on the instrument; v0.5 has not yet been tested on
the instrument. No firmware or instrument contents were changed here.

Checks cover all 81 Density values in both directions during held notes,
out-of-range parameter clamping, pitch/width independence across densities,
block-size invariance, coherent retriggers, shape LFO, combined modulation,
and a one-minute maximum-width/density hold. Five ARM/WASM comparisons,
including an odd component count, agree within 7.2e-7 full scale. SDK header,
API 1.1-0, target and hook addresses were checked. See the JSON reports.

Build from the existing `minilog_xd` workspace with its pinned SDK/toolchains:

```powershell
python prototypes/sqbell/generate_weights.py
python prototypes/sqbell/build.py
node prototypes/sqbell/render_check.cjs
python prototypes/sqbell/analyze.py
python prototypes/sqbell/audit.py
python prototypes/sqbell/package.py
```

The package includes source, build results, test scripts, reports and audio.
SDK/toolchains and the existing Python audit dependencies are not bundled.
