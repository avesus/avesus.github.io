"""Build the small prototype with the existing, pinned XD SDK toolchains."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SDK = ROOT / 'external/logue-sdk'
INC = SDK / 'platform/minilogue-xd/inc'
OUT = HERE / 'build'
DIST = HERE / 'dist'
OUT.mkdir(exist_ok=True)
DIST.mkdir(exist_ok=True)


def run(args):
    subprocess.run([str(a) for a in args], cwd=HERE, check=True)


includes = [f'-I{INC}', f'-I{INC / "utils"}', f'-I{HERE / "src"}']
exports = ['host_init', 'host_param', 'host_note', 'host_pitch', 'host_off',
           'host_lfo', 'host_render', 'cloud_sigma', 'cloud_center',
           'cloud_spacing', 'cloud_normalization', 'cloud_state_bytes',
           'cloud_sources', 'cloud_step']
run([SDK / 'tools/emsdk/upstream/emscripten/em++.bat',
     HERE / 'src/oscillator.cpp', ROOT / 'src/host.cpp', *includes,
     '-DCLOUD_HOST', '-D__osc_api_h', '-O3', '-std=c++11',
     '-fno-exceptions', '-fno-rtti', '-Wno-ignored-attributes',
     '-Wno-unknown-attributes', '--no-entry', '-sMODULARIZE=1',
     '-sEXPORT_NAME=createSqBell', '-sENVIRONMENT=node,web,worker',
     '-sEXPORTED_FUNCTIONS=' + json.dumps(['_' + e for e in exports]),
     '-sEXPORTED_RUNTIME_METHODS=["HEAP32"]', '-sALLOW_MEMORY_GROWTH=0',
     '-sINITIAL_MEMORY=16777216', '-o', DIST / 'sqbell.js'])

gcc = ROOT / 'external/arm-gcc/bin/arm-none-eabi-gcc.exe'
ld = SDK / 'platform/minilogue-xd/dummy-osc/ld'
common = ['-mcpu=cortex-m4', '-mthumb', '-mlittle-endian', '-mfloat-abi=hard',
          '-mfpu=fpv4-sp-d16', '-O3', '-ffunction-sections', '-fdata-sections',
          '-fsingle-precision-constant', '-DSTM32F401xC', '-DCORTEX_USE_FPU=TRUE',
          '-DARM_MATH_CM4', '-D__FPU_PRESENT',
          f'-I{SDK / "platform/ext/CMSIS/CMSIS/Include"}', *includes]
run([gcc, *common, '-std=c11', '-c',
     SDK / 'platform/minilogue-xd/dummy-osc/tpl/_unit.c', '-o', OUT / 'entry.o'])
run([gcc.with_name('arm-none-eabi-g++.exe'), *common, '-std=c++11',
     '-fno-exceptions', '-fno-rtti', '-c', HERE / 'src/oscillator.cpp',
     '-o', OUT / 'oscillator.o'])
run([gcc, *common, '-nostartfiles', OUT / 'entry.o', OUT / 'oscillator.o',
     f'-Wl,-Map={OUT / "sqbell.map"},--gc-sections,--no-warn-mismatch,--library-path={ld},--script={ld / "userosc.ld"}',
     f'-Wl,--just-symbols={ld / "osc_api.syms"}', '-lm', '-o', OUT / 'sqbell.elf'])
run([gcc.with_name('arm-none-eabi-size.exe'), OUT / 'sqbell.elf'])
run([gcc.with_name('arm-none-eabi-objcopy.exe'), '-O', 'binary', OUT / 'sqbell.elf', OUT / 'payload.bin'])
unit = DIST / 'sqbell-v0.5.mnlgxdunit'
with zipfile.ZipFile(unit, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(HERE / 'manifest.json', 'sqbell/manifest.json')
    z.write(OUT / 'payload.bin', 'sqbell/payload.bin')
with zipfile.ZipFile(unit) as z:
    assert z.testzip() is None
files = list((HERE / 'src').glob('*')) + [p for p in DIST.glob('*') if p.suffix != '.zip'] + [HERE / 'manifest.json']
report = {'sdk_commit': subprocess.check_output(['git', '-C', str(SDK), 'rev-parse', 'HEAD'], text=True).strip(),
          'api': '1.1-0', 'target': 'minilogue-xd',
          'files': {str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(OUT / 'build-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
