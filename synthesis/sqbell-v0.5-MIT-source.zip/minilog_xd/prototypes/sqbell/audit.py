"""Actual ARM instruction audit and ARM/WASM parity; not CPU cycle timing."""
import json,math,struct,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from arm_audit import Image

report={'method':'Actual compiled ARM ELF in Unicorn; executed instructions, NOT CPU cycles or instrument timing.', 'cases':[], 'parity':[]}
for n,note,shape in [(16,69,460),(32,69,460),(32,69,1023),(64,69,1023),(96,69,460),(96,69,1023),(96,96,1023)]:
    im=Image(HERE/'build/sqbell.elf')
    im.call('_hook_init',0x200,0x10100);im.call('_hook_param',0,n-1);im.call('_hook_param',6,shape);im.params(note)
    on=im.call('_hook_on',0x20030000)
    counts=[im.cycle()[0] for _ in range(64)]
    im.call('_hook_param',6,1023-shape)
    changes=[im.cycle()[0] for _ in range(64)]
    im.call('_hook_param',0,95 if n!=96 else 15)
    density_changes=[im.cycle()[0] for _ in range(8)]
    report['cases'].append({'density':n,'note':note,'shape':shape,'note_on_instructions':on,
      'steady_instructions_per_sample':sum(counts)/(len(counts)*64),'max_steady_64_frame_instructions':max(counts),
      'max_width_change_64_frame_instructions':max(changes),'max_density_change_64_frame_instructions':max(density_changes)})
report['software_double_helpers']=[s for s in im.syms if s.startswith('__aeabi_d')]
assert not report['software_double_helpers']
for case in json.loads((HERE/'build/wasm-reference.json').read_text()):
    im=Image(HERE/'build/sqbell.elf');im.call('_hook_init',0x200,0x10100)
    im.call('_hook_param',0,case['density']-1);im.call('_hook_param',6,case['shape'])
    im.params(case['note']);im.call('_hook_on',0x20030000)
    samples=[]
    for _ in range(16):
        im.cycle();samples.extend(struct.unpack('<64i',im.u.mem_read(0x20030100,256)))
    errors=[(a-b)/2147483648 for a,b in zip(samples,case['samples'])]
    rec={'density':case['density'],'note':case['note'],'shape':case['shape'],
         'max_absolute_error':max(map(abs,errors)),'rms_error':math.sqrt(sum(e*e for e in errors)/len(errors))}
    assert rec['rms_error']<1e-5,rec
    report['parity'].append(rec)
(HERE/'renders/arm-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
