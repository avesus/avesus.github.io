// Portable harness calls the real minilogue XD hooks from userosc.h.
#include "userosc.h"
#include <stdint.h>
static int32_t samples[1024];
static user_osc_param_t parameters;
extern "C" {
void cloud_seed(unsigned);
void host_init(unsigned seed) { _hook_init(0,0); cloud_seed(seed); parameters={}; }
void host_param(unsigned id,unsigned value) { _hook_param(id,value); }
void host_note(unsigned pitch) { parameters.pitch=uint16_t(pitch); _hook_on(&parameters); }
void host_pitch(unsigned pitch) { parameters.pitch=uint16_t(pitch); }
void host_off() { _hook_off(&parameters); }
void host_lfo(int32_t value) { parameters.shape_lfo=value; }
int32_t *host_render(unsigned frames) { if(frames>1024) frames=1024; _hook_cycle(&parameters,samples,frames); return samples; }
}
